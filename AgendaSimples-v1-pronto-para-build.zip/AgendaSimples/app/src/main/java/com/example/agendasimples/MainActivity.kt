package com.example.agendasimples

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.*

private enum class Page { HOME, AGENDA, FINANCE, NOTES }
private data class Event(val title:String,val date:String,val time:String)
private data class Money(val desc:String,val value:Double,val income:Boolean)
private data class Note(val title:String,val text:String)

class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b); setContent{App()}} }

@Composable fun App(){
 var page by remember{mutableStateOf(Page.HOME)}
 var events by remember{mutableStateOf(listOf<Event>())}
 var money by remember{mutableStateOf(listOf<Money>())}
 var notes by remember{mutableStateOf(listOf<Note>())}
 MaterialTheme { Scaffold(bottomBar={NavigationBar{ listOf(Page.HOME,Page.AGENDA,Page.FINANCE,Page.NOTES).forEach{p->NavigationBarItem(selected=page==p,onClick={page=p},icon={},label={Text(when(p){Page.HOME->"Início";Page.AGENDA->"Agenda";Page.FINANCE->"Financeiro";Page.NOTES->"Notas"})})}}}){pad->
  Box(Modifier.padding(pad).fillMaxSize()){ when(page){Page.HOME->Home(events,money,notes);Page.AGENDA->Agenda(events){events=it};Page.FINANCE->Finance(money){money=it};Page.NOTES->Notes(notes){notes=it} } }
 }}
}

@Composable fun Home(events:List<Event>,money:List<Money>,notes:List<Note>){
 Column(Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("Minha organização",style=MaterialTheme.typography.headlineMedium);Text(SimpleDateFormat("EEEE, dd/MM",Locale("pt","BR")).format(Date()));
 Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Hoje",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(8.dp));Text(if(events.isEmpty())"Nenhum compromisso" else "${events.size} compromisso(s)")}}
 Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Financeiro",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(8.dp));Text("Saldo: R$ %.2f".format(money.sumOf{if(it.income)it.value else -it.value}))}}
 Card(Modifier.fillMaxWidth()){Column(Modifier.padding(18.dp)){Text("Notas",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(8.dp));Text("${notes.size} nota(s)")}}
 Text("Tudo fica salvo somente neste aparelho.",style=MaterialTheme.typography.bodySmall)
 }
}

@Composable fun Agenda(events:List<Event>,set:(List<Event>)->Unit){var t by remember{mutableStateOf("")};var d by remember{mutableStateOf("")};var h by remember{mutableStateOf("")};Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Agenda",style=MaterialTheme.typography.headlineMedium);OutlinedTextField(t,{t=it},label={Text("Compromisso")},modifier=Modifier.fillMaxWidth());OutlinedTextField(d,{d=it},label={Text("Data (dd/mm)")},modifier=Modifier.fillMaxWidth());OutlinedTextField(h,{h=it},label={Text("Hora")},modifier=Modifier.fillMaxWidth());Button(onClick={if(t.isNotBlank()){set(events+Event(t,d,h));t="";d="";h=""}},modifier=Modifier.fillMaxWidth()){Text("Adicionar")};LazyColumn{items(events){e->ListItem(headlineContent={Text(e.title)},supportingContent={Text("${e.date} ${e.time}")},trailingContent={TextButton({set(events-e)}){Text("Excluir")}})}}}}

@Composable fun Finance(money:List<Money>,set:(List<Money>)->Unit){var desc by remember{mutableStateOf("")};var value by remember{mutableStateOf("")};var income by remember{mutableStateOf(true)};Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Financeiro",style=MaterialTheme.typography.headlineMedium);Text("Saldo: R$ %.2f".format(money.sumOf{if(it.income)it.value else -it.value}),style=MaterialTheme.typography.titleLarge);OutlinedTextField(desc,{desc=it},label={Text("Descrição")},modifier=Modifier.fillMaxWidth());OutlinedTextField(value,{value=it},label={Text("Valor")},modifier=Modifier.fillMaxWidth());Row{TextButton({income=true}){Text("Entrada")};TextButton({income=false}){Text("Despesa")}};Button(onClick={value.toDoubleOrNull()?.let{set(money+Money(desc,it,income));desc="";value=""}},modifier=Modifier.fillMaxWidth()){Text("Adicionar")};LazyColumn{items(money){m->ListItem(headlineContent={Text(m.desc)},supportingContent={Text(if(m.income)"Entrada" else "Despesa")},trailingContent={Text("R$ %.2f".format(m.value))})}}}}

@Composable fun Notes(notes:List<Note>,set:(List<Note>)->Unit){var title by remember{mutableStateOf("")};var text by remember{mutableStateOf("")};Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){Text("Bloco de notas",style=MaterialTheme.typography.headlineMedium);OutlinedTextField(title,{title=it},label={Text("Título")},modifier=Modifier.fillMaxWidth());OutlinedTextField(text,{text=it},label={Text("Nota")},modifier=Modifier.fillMaxWidth(),minLines=4);Button(onClick={if(title.isNotBlank()||text.isNotBlank()){set(notes+Note(title,text));title="";text=""}},modifier=Modifier.fillMaxWidth()){Text("Salvar nota")};LazyColumn{items(notes){n->ListItem(headlineContent={Text(n.title)},supportingContent={Text(n.text)},trailingContent={TextButton({set(notes-n)}){Text("Excluir")}})}}}}
